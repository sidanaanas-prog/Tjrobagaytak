import { Router, type IRouter, type Request, type Response } from "express";
import { v2 as cloudinary } from "cloudinary";
import { objectStorageClient } from "../lib/objectStorage";
import { authenticate } from "../lib/auth";

const router: IRouter = Router();

// ─── detect environment ────────────────────────────────────────────────────

const IS_REPLIT = !!process.env.REPLIT_DOMAINS || !!process.env.REPL_ID || !!process.env.REPLIT_OWNER_ID;

// ─── Cloudinary (fallback for non-Replit hosts like Render) ─────────────

function initCloudinary() {
  const name = process.env.CLOUDINARY_CLOUD_NAME || "";
  const key  = process.env.CLOUDINARY_API_KEY  || "";
  const secret = process.env.CLOUDINARY_API_SECRET || "";
  if (!name || !key || !secret) {
    console.warn("[Upload] Cloudinary env vars missing — uploads will fail on non-Replit hosts");
  }
  cloudinary.config({ cloud_name: name, api_key: key, api_secret: secret });
}

initCloudinary(); // always configure Cloudinary (used by all upload routes)

async function uploadToCloudinary(base64: string, folder: string, resourceType: "image" | "video" | "auto" = "image"): Promise<string> {
  const result = await cloudinary.uploader.upload(base64, {
    folder: `gaytak/${folder}`,
    resource_type: resourceType,
  });
  return result.secure_url;
}

function isAudioContentType(contentType: string): boolean {
  return contentType.startsWith("audio/") || contentType === "video/mp4" || contentType === "video/webm";
}

// ─── Replit Object Storage ─────────────────────────────────────────────────

function getPublicBucketAndPrefix(): { bucket: string; prefix: string } {
  const paths = (process.env.PUBLIC_OBJECT_SEARCH_PATHS || "").split(",").map((p) => p.trim()).filter(Boolean);
  if (!paths[0]) throw new Error("PUBLIC_OBJECT_SEARCH_PATHS not configured");
  const parts = paths[0].replace(/^\//, "").split("/");
  return { bucket: parts[0], prefix: parts.slice(1).join("/") };
}

function getHost(req: Request): string {
  if (process.env.REPLIT_DOMAINS) {
    return process.env.REPLIT_DOMAINS.split(",")[0].trim();
  }
  const forwarded = req.headers["x-forwarded-host"] as string;
  if (forwarded) return forwarded;
  const host = req.headers.host || "localhost";
  return host === "localhost:80" ? "localhost" : host;
}

async function uploadToReplitStorage(buffer: Buffer, filePath: string, contentType: string, req: Request): Promise<string> {
  const { bucket: bucketName, prefix } = getPublicBucketAndPrefix();
  const objectName = prefix ? `${prefix}/${filePath}` : filePath;
  const file = objectStorageClient.bucket(bucketName).file(objectName);
  await file.save(buffer, { metadata: { contentType }, resumable: false });
  const host = getHost(req);
  return `https://${host}/api/storage/public-objects/${filePath}`;
}

// ─── POST /upload ─────────────────────────────────────────────────────────

router.post("/upload", authenticate, async (req: Request, res: Response): Promise<void> => {
  const { base64, path: filePath, contentType = "image/jpeg" } = req.body;
  if (!base64 || !filePath) {
    res.status(400).json({ error: "base64 and path are required" });
    return;
  }
  try {
    const cleanBase64 = base64.replace(/^data:.*?;base64,/, "");
    const folder = filePath.split("/")[0] || "general";
    const resourceType = isAudioContentType(contentType) ? "video" : "image";

    let url: string;

    if (IS_REPLIT) {
      // Use Replit Object Storage (works on both dev & prod)
      const buffer = Buffer.from(cleanBase64, "base64");
      url = await uploadToReplitStorage(buffer, filePath, contentType, req);
      console.log(`[Upload] ✅ Replit Storage (${resourceType}): ${filePath}`);
    } else {
      // Fallback to Cloudinary (Render / external)
      const cloudinaryBase64 = resourceType === "video"
        ? `data:video/webm;base64,${cleanBase64}`
        : base64;
      url = await uploadToCloudinary(cloudinaryBase64, folder, resourceType);
      console.log(`[Upload] ✅ Cloudinary (${resourceType}): ${filePath}`);
    }

    res.json({ url, path: filePath });
  } catch (err: any) {
    console.error("[Upload] ❌", err?.message || err);
    res.status(500).json({ error: "Upload failed: " + (err?.message || "unknown") });
  }
});

export default router;
